I would recommend downloading the Official Unity PostProcessing stack (https://www.assetstore.unity3d.com/en/#!/content/83912) and turning on Ambient Occlusion to improve the look of Low Poly models.

All pieces are <1000 polygons, and come in 2 visually identical versions: standard (separate material) and optimized (single shared texture) version to allow both customization and optimization, depending on your needs.

Full list of all 20 models:
- Column 1
- Column 2
- Floor - Stone 1
- Roof
- Roof - Square
- Roof Support
- Roof Support - Square
- Stairs - Stone
- Stairs - Stone Corner
- Tree 2
- Wall 1 - Short
- Wall 2
- Wall 2 - Corner
- Wall 2 - Door
- Wall 2 - Window
- Wall Column 1
- Wall Divider 1
- Wall Divider 1 - Corner
- Wall Divider 2
- Wall Divider 2 - Corner
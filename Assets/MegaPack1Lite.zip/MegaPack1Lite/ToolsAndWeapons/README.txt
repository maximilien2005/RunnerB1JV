I would recommend downloading the Official Unity PostProcessing stack (https://www.assetstore.unity3d.com/en/#!/content/83912) and turning on Ambient Occlusion to improve the look of Low Poly models.

Collection of 20 low poly weapons and tools.

Full list of all 20 models:
- Arrow
- Axe
- Battle Axe
- Bow
- Bucket
- Dagger
- Fishing Pole
- Hammer
- Mallet
- Pickaxe
- Quiver
- Rake
- Scythe
- Shield (Leather)
- Shield (Metal)
- Shovel
- Spear
- Sword (Large)
- Sword (Small)

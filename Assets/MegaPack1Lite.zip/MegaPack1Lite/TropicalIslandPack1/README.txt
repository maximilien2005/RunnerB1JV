I would recommend downloading the Official Unity PostProcessing stack (https://www.assetstore.unity3d.com/en/#!/content/83912) and turning on Ambient Occlusion to improve the look of Low Poly models.

All pieces are < 500 polygons.

Full list of all 40 models:
- Barrel
- Bush (Variation 1)
- Bush (Variation 2)
- Bush (Variation 3)
- Bush (Palm)
- Campfire
- Canopy (Slanted)
- Canopy (Straight)
- Cattail
- Chest
- Crate (Variation 1)
- Crate (Variation 2)
- Crate (Variation 3)
- Dirt Pile
- Dock (Variation 1)
- Dock (Variation 2)
- Fence
- Flower (Variation 1)
- Flower (Variation 2)
- Ladder
- Oar
- Palm Tree (Variation 1)
- Palm Tree (Variation 2)
- Palm Tree (Variation 3)
- Palm Tree (Variation 4)
- Plank
- Plant (Variation 1)
- Plant (Variation 2)
- Plant (Variation 3)
- Plant (Variation 4)
- Plant (Variation 5)
- Rock (Variation 1)
- Rock (Variation 2)
- Rock (Variation 3)
- Rock (Variation 4)
- Rock (Variation 5)
- Rowboat
- Shovel
- Stairs
- Torch
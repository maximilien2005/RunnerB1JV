Lowpoly Medieval Buildings

Package contains 13 PBR Materials (albedo, normalmaps, smoothness, metalness)
and 21 meshes:
-bakery
-barrack
-dairy
-gate
-house
-ironworks
-market
-mine
-palisade
-quarry
-sawmill
-slaughterhouse
-blacksmith
-stairs
-tower
-tower_corner
-tower_small
-wall
-warehouse
-windmill

All meshes have about 1 000 tris


Author: Szymon �ukaszuk 

lukaszukszymon@gmail.com